@echo off
setlocal

set DIRNAME=%~dp0
if "%DIRNAME%"=="" set DIRNAME=.
set APP_HOME=%DIRNAME%

set GRADLE_USER_HOME=%APP_HOME%.gradle

set CLASSPATH=%APP_HOME%gradle\wrapper\gradle-wrapper.jar
set GRADLE_OPTS=-Xmx2048m -Dfile.encoding=UTF-8

if not defined JAVA_HOME (
    set JAVA_EXE=java
) else (
    set JAVA_EXE=%JAVA_HOME%\bin\java.exe
)

if not defined ANDROID_HOME (
    set ANDROID_HOME=%LOCALAPPDATA%\Android\Sdk
)

"%JAVA_EXE%" %GRADLE_OPTS% -classpath "%CLASSPATH%" org.gradle.wrapper.GradleWrapperMain %*
