package com.ytdownloader.data.api

import com.ytdownloader.data.model.DownloadRequest
import com.ytdownloader.data.model.DownloadResponse
import com.ytdownloader.data.model.InfoRequest
import com.ytdownloader.data.model.ProgressInfo
import com.ytdownloader.data.model.StatusResponse
import com.ytdownloader.data.model.TaskListResponse
import com.ytdownloader.data.model.VideoInfo
import okhttp3.ResponseBody
import retrofit2.Response
import retrofit2.http.Body
import retrofit2.http.DELETE
import retrofit2.http.GET
import retrofit2.http.POST
import retrofit2.http.Path
import retrofit2.http.Streaming

interface ApiService {

    @POST("/api/info")
    suspend fun getVideoInfo(@Body request: InfoRequest): VideoInfo

    @POST("/api/download")
    suspend fun startDownload(@Body request: DownloadRequest): DownloadResponse

    @GET("/api/progress/{taskId}")
    suspend fun getProgress(@Path("taskId") taskId: String): ProgressInfo

    @Streaming
    @GET("/api/file/{taskId}")
    suspend fun downloadFile(@Path("taskId") taskId: String): Response<ResponseBody>

    @POST("/api/cancel/{taskId}")
    suspend fun cancelDownload(@Path("taskId") taskId: String): StatusResponse

    @DELETE("/api/file/{taskId}")
    suspend fun deleteFile(@Path("taskId") taskId: String): StatusResponse

    @GET("/api/tasks")
    suspend fun listTasks(): TaskListResponse
}
