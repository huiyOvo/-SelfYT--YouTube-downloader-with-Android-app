package com.ytdownloader.ui.screen

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import com.ytdownloader.viewmodel.DownloadTask
import com.ytdownloader.viewmodel.MainViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DownloadScreen(viewModel: MainViewModel) {
    // Read listVersion to trigger recomposition on changes
    val currentVersion = viewModel.listVersion

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("下载管理 (${viewModel.downloadTasks.size})") },
                navigationIcon = {
                    IconButton(onClick = { viewModel.goHome() }) {
                        Icon(Icons.Filled.ArrowBack, "返回")
                    }
                }
            )
        }
    ) { padding ->
        if (viewModel.downloadTasks.isEmpty()) {
            Box(
                modifier = Modifier.fillMaxSize().padding(padding),
                contentAlignment = Alignment.Center
            ) {
                Text("暂无下载任务", style = MaterialTheme.typography.bodyLarge,
                    color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        } else {
            LazyColumn(
                modifier = Modifier.fillMaxSize().padding(padding),
                contentPadding = PaddingValues(12.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(viewModel.downloadTasks, key = { it.taskId }) { task ->
                    DownloadItem(task, viewModel)
                }
            }
        }
    }
}

@Composable
private fun DownloadItem(task: DownloadTask, viewModel: MainViewModel) {
    Card(modifier = Modifier.fillMaxWidth()) {
        Column(modifier = Modifier.padding(12.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.Top
            ) {
                // Thumbnail
                if (task.thumbnail.isNotBlank()) {
                    AsyncImage(
                        model = task.thumbnail,
                        contentDescription = null,
                        modifier = Modifier
                            .size(72.dp)
                            .clip(MaterialTheme.shapes.small),
                        contentScale = ContentScale.Crop
                    )
                    Spacer(Modifier.width(10.dp))
                }

                Column(modifier = Modifier.weight(1f)) {
                    Text(task.title, maxLines = 2, overflow = TextOverflow.Ellipsis,
                        style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Medium)
                    Spacer(Modifier.height(2.dp))
                    Text(task.formatLabel, style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant)

                    Spacer(Modifier.height(8.dp))

                    when (task.status) {
                        "downloading" -> {
                            LinearProgressIndicator(
                                progress = (task.percent / 100.0).toFloat().coerceIn(0f, 1f),
                                modifier = Modifier.fillMaxWidth()
                            )
                            Spacer(Modifier.height(4.dp))
                            Row {
                                Text("${task.percent.toInt()}%", style = MaterialTheme.typography.bodySmall)
                                task.speed?.let { spd ->
                                    Text("  |  ${formatSpeed(spd)}", style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                            }
                        }
                        "starting" -> {
                            LinearProgressIndicator(modifier = Modifier.fillMaxWidth())
                            Spacer(Modifier.height(4.dp))
                            Text("准备中...", style = MaterialTheme.typography.bodySmall)
                        }
                        "processing" -> {
                            LinearProgressIndicator(modifier = Modifier.fillMaxWidth())
                            Spacer(Modifier.height(4.dp))
                            Text("合并/转换中...", style = MaterialTheme.typography.bodySmall)
                        }
                        "compressing" -> {
                            LinearProgressIndicator(
                                progress = (task.percent / 100.0).toFloat().coerceIn(0f, 1f),
                                modifier = Modifier.fillMaxWidth()
                            )
                            Spacer(Modifier.height(4.dp))
                            Text("NVENC压缩中... ${task.percent.toInt()}%", style = MaterialTheme.typography.bodySmall)
                        }
                        "transferring" -> {
                            LinearProgressIndicator(modifier = Modifier.fillMaxWidth())
                            Spacer(Modifier.height(4.dp))
                            Text("传输到手机...", style = MaterialTheme.typography.bodySmall)
                        }
                        "complete" -> {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Filled.CheckCircle, null, tint = MaterialTheme.colorScheme.primary,
                                    modifier = Modifier.size(16.dp))
                                Spacer(Modifier.width(4.dp))
                                Text("已完成", style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.primary)
                                task.filesizeStr?.let {
                                    Text("  |  $it", style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                            }
                        }
                        "cancelled" -> {
                            Text("已取消", style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        "error" -> {
                            Text("下载失败", style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.error)
                        }
                    }
                }
            }

            // Action buttons
            if (task.status == "downloading" || task.status == "starting" || task.status == "processing" || task.status == "compressing") {
                Spacer(Modifier.height(8.dp))
                TextButton(
                    onClick = { viewModel.cancelDownload(task) },
                    colors = ButtonDefaults.textButtonColors(contentColor = MaterialTheme.colorScheme.error)
                ) {
                    Icon(Icons.Filled.Close, null, modifier = Modifier.size(16.dp))
                    Spacer(Modifier.width(4.dp))
                    Text("取消下载")
                }
            }
            if (task.status == "complete" || task.status == "cancelled" || task.status == "error") {
                Spacer(Modifier.height(8.dp))
                TextButton(onClick = { viewModel.deleteTask(task) }) {
                    Icon(Icons.Filled.Delete, null, modifier = Modifier.size(16.dp))
                    Spacer(Modifier.width(4.dp))
                    Text("删除")
                }
            }
        }
    }
}

private fun formatSpeed(bytesPerSec: Double): String {
    if (bytesPerSec < 1024) return "${bytesPerSec.toInt()} B/s"
    val kb = bytesPerSec / 1024
    return if (kb < 1024) "${kb.toInt()} KB/s" else "%.1f MB/s".format(kb / 1024)
}
