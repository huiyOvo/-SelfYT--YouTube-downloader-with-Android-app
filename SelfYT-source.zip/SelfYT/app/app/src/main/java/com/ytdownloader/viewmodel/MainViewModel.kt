package com.ytdownloader.viewmodel

import android.app.Application
import android.content.ContentValues
import android.content.Context
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import androidx.documentfile.provider.DocumentFile
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.ytdownloader.data.api.ApiService
import com.ytdownloader.data.model.DownloadRequest
import com.ytdownloader.data.model.InfoRequest
import com.ytdownloader.data.model.VideoInfo
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import java.io.File
import java.io.FileOutputStream
import java.util.concurrent.TimeUnit

val Context.dataStore by preferencesDataStore("settings")

data class DownloadTask(
    val taskId: String,
    val title: String,
    val formatLabel: String,
    val thumbnail: String,
    var status: String,   // starting, downloading, processing, transferring, complete, cancelled, error
    var percent: Double,
    var speed: Double?,
    var filesizeStr: String?,
    var savedPath: String?,
    val url: String,
    val resolution: String,
    val format: String
)

class MainViewModel(application: Application) : AndroidViewModel(application) {

    sealed class Screen {
        object Home : Screen()
        object Format : Screen()
        object Downloads : Screen()
    }

    var screen by mutableStateOf<Screen>(Screen.Home)
    var serverUrl by mutableStateOf("http://192.168.1.4:5000")
    var youtubeUrl by mutableStateOf("")
    var isLoading by mutableStateOf(false)
    var error by mutableStateOf<String?>(null)
    var videoInfo by mutableStateOf<VideoInfo?>(null)
    var selectedOptionIndex by mutableIntStateOf(0)
    var downloadPath by mutableStateOf("相册 (DCIM)")
    var customDirUri by mutableStateOf<Uri?>(null)
    var compressEnabled by mutableStateOf(false)

    val downloadTasks = mutableListOf<DownloadTask>()
    private val activeJobs = mutableMapOf<String, Job>()
    var listVersion by mutableIntStateOf(0)
        private set

    private val prefs = application.dataStore
    private val serverUrlKey = stringPreferencesKey("server_url")
    private val downloadPathKey = stringPreferencesKey("download_path")
    private val customDirUriKey = stringPreferencesKey("custom_dir_uri")
    private val compressKey = booleanPreferencesKey("compress_enabled")

    private var _api: ApiService? = null
    private var _baseUrl: String = ""

    init {
        viewModelScope.launch {
            prefs.data.collect { prefs ->
                prefs[serverUrlKey]?.let { serverUrl = it }
                prefs[downloadPathKey]?.let { downloadPath = it }
                prefs[customDirUriKey]?.let { customDirUri = Uri.parse(it) }
                compressEnabled = prefs[compressKey] ?: false
            }
        }
    }

    private fun getApi(): ApiService {
        if (_api == null || _baseUrl != serverUrl) {
            _baseUrl = serverUrl.trimEnd('/') + "/"
            val client = OkHttpClient.Builder()
                .connectTimeout(10, TimeUnit.SECONDS)
                .readTimeout(120, TimeUnit.SECONDS)
                .writeTimeout(60, TimeUnit.SECONDS)
                .build()
            _api = Retrofit.Builder()
                .baseUrl(_baseUrl)
                .client(client)
                .addConverterFactory(GsonConverterFactory.create())
                .build()
                .create(ApiService::class.java)
        }
        return _api!!
    }

    fun saveServerUrl(url: String) { serverUrl = url; viewModelScope.launch { prefs.edit { it[serverUrlKey] = url } }; _api = null }
    fun saveDownloadPath(path: String) { downloadPath = path; viewModelScope.launch { prefs.edit { it[downloadPathKey] = path } } }
    fun saveCustomDirUri(uri: Uri?) { customDirUri = uri; viewModelScope.launch { prefs.edit { it[customDirUriKey] = uri?.toString() ?: "" } } }
    fun saveCompressEnabled(v: Boolean) { compressEnabled = v; viewModelScope.launch { prefs.edit { it[compressKey] = v } } }

    fun onListChanged() { listVersion++ }

    fun parseVideo() {
        if (youtubeUrl.isBlank()) { error = "请输入 YouTube 链接"; return }
        error = null; isLoading = true
        viewModelScope.launch {
            try {
                videoInfo = getApi().getVideoInfo(InfoRequest(youtubeUrl))
                selectedOptionIndex = 0
                screen = Screen.Format
            } catch (e: Exception) { error = "解析失败: ${e.message}" }
            finally { isLoading = false }
        }
    }

    fun addDownload() {
        val info = videoInfo ?: return
        val option = info.allOptions.getOrNull(selectedOptionIndex) ?: return

        isLoading = true
        viewModelScope.launch {
            try {
                val req = DownloadRequest(url = youtubeUrl, resolution = option.label, format = option.format, compress = compressEnabled)
                val resp = getApi().startDownload(req)

                val task = DownloadTask(
                    taskId = resp.task_id, title = info.title,
                    formatLabel = option.label, thumbnail = info.thumbnail,
                    status = "starting", percent = 0.0, speed = null,
                    filesizeStr = option.filesizeStr, savedPath = null,
                    url = youtubeUrl, resolution = option.label, format = option.format
                )
                downloadTasks.add(0, task)
                onListChanged()

                screen = Screen.Downloads
                youtubeUrl = ""
                videoInfo = null
                pollTask(task)
            } catch (e: Exception) { error = "下载失败: ${e.message}" }
            finally { isLoading = false }
        }
    }

    private fun pollTask(task: DownloadTask) {
        val job = viewModelScope.launch {
            while (true) {
                delay(500)
                try {
                    val p = getApi().getProgress(task.taskId)
                    task.status = p.status ?: task.status
                    task.percent = p.percent ?: 0.0
                    task.speed = p.speed
                    if (p.filesize_str != null) task.filesizeStr = p.filesize_str
                    onListChanged()

                    when (p.status) {
                        "complete" -> {
                            transferFile(task)
                            return@launch
                        }
                        "cancelled", "error" -> {
                            task.status = p.status ?: "error"
                            task.speed = null
                            onListChanged()
                            return@launch
                        }
                        "compressing" -> {
                            task.status = "compressing"
                            task.percent = p.percent ?: 0.0
                            onListChanged()
                        }
                    }
                } catch (_: Exception) { }
            }
        }
        activeJobs[task.taskId] = job
    }

    fun cancelDownload(task: DownloadTask) {
        viewModelScope.launch {
            try { getApi().cancelDownload(task.taskId) } catch (_: Exception) { }
        }
        activeJobs[task.taskId]?.cancel()
        activeJobs.remove(task.taskId)
        task.status = "cancelled"
        task.speed = null
        onListChanged()
    }

    fun deleteTask(task: DownloadTask) {
        viewModelScope.launch {
            try { getApi().deleteFile(task.taskId) } catch (_: Exception) { }
        }
        activeJobs[task.taskId]?.cancel()
        activeJobs.remove(task.taskId)
        downloadTasks.remove(task)
        onListChanged()
    }

    private fun transferFile(task: DownloadTask) {
        task.status = "transferring"
        onListChanged()

        viewModelScope.launch(Dispatchers.IO) {
            try {
                val response = getApi().downloadFile(task.taskId)
                if (!response.isSuccessful) {
                    task.status = "error"; task.speed = null; onListChanged(); return@launch
                }
                val body = response.body()
                if (body == null) {
                    task.status = "error"; task.speed = null; onListChanged(); return@launch
                }

                val context = getApplication<Application>()
                val cacheDir = context.cacheDir
                val tmpFile = File(cacheDir, "yt_download_${task.taskId}")
                FileOutputStream(tmpFile).use { out ->
                    body.byteStream().use { inp ->
                        val buf = ByteArray(8192)
                        var r: Int
                        while (inp.read(buf).also { r = it } != -1) out.write(buf, 0, r)
                    }
                }

                val saved = saveToStorage(context, autoFilename(task), tmpFile)
                tmpFile.delete()

                task.status = "complete"
                task.savedPath = saved
                task.speed = null
                onListChanged()
            } catch (e: Exception) {
                task.status = "error"; task.speed = null; onListChanged()
            }
        }
    }

    private fun autoFilename(task: DownloadTask): String {
        val ext = if (task.format == "mp3") ".mp3" else ".mp4"
        val safe = task.title.replace(Regex("[/\\\\:*?\"<>|]"), "_").take(80)
        return "$safe$ext"
    }

    private fun saveToStorage(context: Context, filename: String, tmpFile: File): String {
        val safeName = filename.replace(Regex("[/\\\\:*?\"<>|]"), "_")

        // Custom path via SAF
        if (downloadPath.contains("自定义") && customDirUri != null) {
            val docDir = DocumentFile.fromTreeUri(context, customDirUri!!)
            if (docDir != null && docDir.canWrite()) {
                val mime = if (safeName.endsWith(".mp3")) "audio/mpeg" else "video/mp4"
                docDir.createFile(mime, safeName)?.uri?.let { uri ->
                    context.contentResolver.openOutputStream(uri)?.use { out ->
                        tmpFile.inputStream().use { it.copyTo(out) }
                    }
                    return "自定义目录/$safeName"
                }
            }
        }

        // MediaStore (Android 10+)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            try {
                val values = ContentValues().apply {
                    put(MediaStore.MediaColumns.DISPLAY_NAME, safeName)
                    put(MediaStore.MediaColumns.IS_PENDING, 1)
                    when {
                        safeName.endsWith(".mp3") -> {
                            put(MediaStore.MediaColumns.MIME_TYPE, "audio/mpeg")
                            put(MediaStore.MediaColumns.RELATIVE_PATH, "Music/YTDownloader")
                        }
                        downloadPath.contains("下载") -> {
                            put(MediaStore.MediaColumns.MIME_TYPE, if (safeName.endsWith(".mp3")) "audio/mpeg" else "video/mp4")
                            put(MediaStore.MediaColumns.RELATIVE_PATH, "Download/YTDownloader")
                        }
                        else -> {
                            put(MediaStore.MediaColumns.MIME_TYPE, "video/mp4")
                            put(MediaStore.MediaColumns.RELATIVE_PATH, "DCIM/YTDownloader")
                        }
                    }
                }
                val collection = if (safeName.endsWith(".mp3")) MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
                                 else MediaStore.Video.Media.EXTERNAL_CONTENT_URI
                val uri = context.contentResolver.insert(collection, values)
                uri?.let {
                    context.contentResolver.openOutputStream(it)?.use { out ->
                        tmpFile.inputStream().use { inp -> inp.copyTo(out) }
                    }
                    values.clear(); values.put(MediaStore.MediaColumns.IS_PENDING, 0)
                    context.contentResolver.update(it, values, null, null)
                    return safeName
                }
            } catch (_: Exception) { }
        }

        // Fallback
        val dir = context.getExternalFilesDir(
            if (safeName.endsWith(".mp3")) Environment.DIRECTORY_MUSIC else Environment.DIRECTORY_MOVIES
        )
        if (dir != null) {
            if (!dir.exists()) dir.mkdirs()
            val dest = File(dir, safeName)
            tmpFile.copyTo(dest, overwrite = true)
            return dest.absolutePath
        }
        throw RuntimeException("无法创建保存目录")
    }

    fun goHome() { screen = Screen.Home; error = null; videoInfo = null }
}
