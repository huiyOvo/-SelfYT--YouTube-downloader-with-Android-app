package com.ytdownloader.data.model

data class VideoInfo(
    val id: String,
    val title: String,
    val thumbnail: String,
    val duration: Int,
    val duration_str: String,
    val uploader: String,
    val video_options: List<VideoOption>,
    val audio_option: AudioOption
) {
    val allOptions: List<FormatOption>
        get() {
            val list = mutableListOf<FormatOption>()
            for (v in video_options) {
                list.add(FormatOption(v.resolution, "mp4", v.filesize, v.filesize_str))
            }
            list.add(FormatOption("MP3音频", "mp3", audio_option.filesize, audio_option.filesize_str))
            return list
        }
}

data class VideoOption(
    val resolution: String,
    val height: Int,
    val ext: String,
    val filesize: Long?,
    val filesize_str: String,
    val note: String,
    val fps: Double?
)

data class AudioOption(
    val ext: String,
    val filesize: Long?,
    val filesize_str: String,
    val bitrate: String
)

data class FormatOption(
    val label: String,
    val format: String,
    val filesize: Long?,
    val filesizeStr: String
)

data class DownloadResponse(val task_id: String)

data class ProgressInfo(
    val status: String?,
    val percent: Double?,
    val speed: Double?,
    val eta: Int?,
    val message: String?,
    val filename: String?,
    val filesize_str: String?
)

data class InfoRequest(val url: String)
data class DownloadRequest(val url: String, val resolution: String, val format: String, val compress: Boolean = false)

data class TaskListResponse(val tasks: List<TaskInfo>)

data class TaskInfo(
    val task_id: String,
    val status: String?,
    val percent: Double?,
    val speed: Double?,
    val message: String?,
    val filename: String?,
    val filesize_str: String?
)

data class StatusResponse(val status: String, val message: String?)
