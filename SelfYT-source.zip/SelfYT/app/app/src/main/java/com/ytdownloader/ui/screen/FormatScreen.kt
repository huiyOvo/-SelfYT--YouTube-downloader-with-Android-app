package com.ytdownloader.ui.screen

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Download
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import com.ytdownloader.viewmodel.MainViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun FormatScreen(viewModel: MainViewModel) {
    val info = viewModel.videoInfo ?: return

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("选择格式") },
                navigationIcon = {
                    IconButton(onClick = { viewModel.goHome() }) {
                        Icon(Icons.Filled.ArrowBack, "返回")
                    }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(rememberScrollState())
                .padding(16.dp)
        ) {
            // Thumbnail
            AsyncImage(
                model = info.thumbnail,
                contentDescription = null,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(200.dp)
                    .clip(MaterialTheme.shapes.medium),
                contentScale = ContentScale.Crop
            )

            Spacer(Modifier.height(12.dp))

            Text(info.title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
            Text("${info.uploader}  |  ${info.duration_str}", style = MaterialTheme.typography.bodySmall)

            Spacer(Modifier.height(20.dp))

            Text("选择下载格式:", style = MaterialTheme.typography.titleSmall)
            Spacer(Modifier.height(8.dp))

            info.allOptions.forEachIndexed { index, option ->
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 3.dp)
                        .clickable { viewModel.selectedOptionIndex = index }
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        RadioButton(
                            selected = viewModel.selectedOptionIndex == index,
                            onClick = { viewModel.selectedOptionIndex = index }
                        )
                        Spacer(Modifier.width(8.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(option.label, style = MaterialTheme.typography.bodyLarge)
                            Text(option.filesizeStr, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                }
            }

            Spacer(Modifier.height(12.dp))

            // Compress option
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { viewModel.saveCompressEnabled(!viewModel.compressEnabled) },
                verticalAlignment = Alignment.CenterVertically
            ) {
                Checkbox(
                    checked = viewModel.compressEnabled,
                    onCheckedChange = { viewModel.saveCompressEnabled(it) }
                )
                Column(modifier = Modifier.weight(1f)) {
                    Text("NVENC视频压缩", style = MaterialTheme.typography.bodyMedium)
                    Text("压缩到720p, 目标≤95MB", style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }

            Spacer(Modifier.height(8.dp))

            Button(
                onClick = { viewModel.addDownload() },
                modifier = Modifier.fillMaxWidth().height(50.dp),
                enabled = !viewModel.isLoading
            ) {
                Icon(Icons.Filled.Download, contentDescription = null)
                Spacer(Modifier.width(8.dp))
                Text(if (viewModel.isLoading) "准备中..." else "开始下载")
            }

            viewModel.error?.let {
                Spacer(Modifier.height(8.dp))
                Text(it, color = MaterialTheme.colorScheme.error)
            }
        }
    }
}
