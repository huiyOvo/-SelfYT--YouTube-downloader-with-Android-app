package com.ytdownloader

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.darkColorScheme
import androidx.compose.ui.Modifier
import com.ytdownloader.ui.screen.DownloadScreen
import com.ytdownloader.ui.screen.FormatScreen
import com.ytdownloader.ui.screen.HomeScreen
import com.ytdownloader.ui.theme.Pink40
import com.ytdownloader.ui.theme.Purple40
import com.ytdownloader.ui.theme.PurpleGrey40
import com.ytdownloader.ui.theme.SurfaceDark
import com.ytdownloader.viewmodel.MainViewModel

class MainActivity : ComponentActivity() {

    private val viewModel: MainViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setContent {
            val darkTheme = isSystemInDarkTheme()

            MaterialTheme(
                colorScheme = if (darkTheme) darkColorScheme(
                    primary = Purple40,
                    secondary = PurpleGrey40,
                    tertiary = Pink40,
                    surface = SurfaceDark,
                ) else androidx.compose.material3.lightColorScheme()
            ) {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    when (val screen = viewModel.screen) {
                        is MainViewModel.Screen.Home -> HomeScreen(viewModel)
                        is MainViewModel.Screen.Format -> FormatScreen(viewModel)
                        is MainViewModel.Screen.Downloads -> DownloadScreen(viewModel)
                    }
                }
            }
        }
    }
}
