package com.ytdownloader.ui.screen

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.FolderOpen
import androidx.compose.material.icons.filled.ListAlt
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.ytdownloader.viewmodel.MainViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(viewModel: MainViewModel) {
    var showSettings by remember { mutableStateOf(false) }
    var serverInput by remember { mutableStateOf(viewModel.serverUrl) }
    var urlInput by remember { mutableStateOf(viewModel.youtubeUrl) }
    val context = LocalContext.current
    @Suppress("UNUSED_EXPRESSION") val currentVersion = viewModel.listVersion

    val dirPicker = rememberLauncherForActivityResult(
        ActivityResultContracts.OpenDocumentTree()
    ) { uri: Uri? ->
        if (uri != null) {
            context.contentResolver.takePersistableUriPermission(uri,
                android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION or
                android.content.Intent.FLAG_GRANT_WRITE_URI_PERMISSION)
            viewModel.saveCustomDirUri(uri)
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(20.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Spacer(Modifier.height(40.dp))

        Text("YouTube 下载", style = MaterialTheme.typography.headlineLarge)

        // Downloads button
        if (viewModel.downloadTasks.isNotEmpty()) {
            Spacer(Modifier.height(16.dp))
            OutlinedButton(
                onClick = { viewModel.screen = MainViewModel.Screen.Downloads },
                modifier = Modifier.fillMaxWidth()
            ) {
                Icon(Icons.Filled.ListAlt, null, modifier = Modifier.size(20.dp))
                Spacer(Modifier.width(8.dp))
                Text("下载管理 (${viewModel.downloadTasks.size})")
            }
        }

        Spacer(Modifier.height(24.dp))

        OutlinedTextField(
            value = urlInput,
            onValueChange = { urlInput = it; viewModel.youtubeUrl = it },
            label = { Text("YouTube 链接") },
            placeholder = { Text("粘贴 YouTube 视频链接...") },
            modifier = Modifier.fillMaxWidth(),
            singleLine = true
        )

        Spacer(Modifier.height(16.dp))

        Button(
            onClick = { viewModel.parseVideo() },
            modifier = Modifier
                .fillMaxWidth()
                .height(50.dp),
            enabled = !viewModel.isLoading && urlInput.isNotBlank()
        ) {
            if (viewModel.isLoading) {
                CircularProgressIndicator(modifier = Modifier.size(22.dp), strokeWidth = 2.dp)
                Spacer(Modifier.width(8.dp))
                Text("解析中...")
            } else {
                Icon(Icons.Filled.Download, contentDescription = null)
                Spacer(Modifier.width(8.dp))
                Text("解析视频")
            }
        }

        viewModel.error?.let {
            Spacer(Modifier.height(12.dp))
            Text(it, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodyMedium)
        }

        Spacer(Modifier.height(24.dp))

        // Settings card
        Card(modifier = Modifier.fillMaxWidth()) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(Icons.Filled.Settings, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                Spacer(Modifier.width(8.dp))
                Text("服务器地址: ${viewModel.serverUrl}", style = MaterialTheme.typography.bodySmall)
                Spacer(Modifier.weight(1f))
                TextButton(onClick = { showSettings = !showSettings }) {
                    Text(if (showSettings) "收起" else "修改")
                }
            }

            if (showSettings) {
                Column(modifier = Modifier.padding(horizontal = 16.dp)) {
                    OutlinedTextField(
                        value = serverInput,
                        onValueChange = { serverInput = it },
                        label = { Text("服务器地址") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true
                    )
                    Spacer(Modifier.height(8.dp))
                    Button(onClick = {
                        viewModel.saveServerUrl(serverInput)
                        showSettings = false
                    }, modifier = Modifier.fillMaxWidth()) {
                        Text("保存服务器地址")
                    }
                    Spacer(Modifier.height(8.dp))

                    // Download path
                    Text("下载保存位置:", style = MaterialTheme.typography.bodySmall)
                    Spacer(Modifier.height(4.dp))

                    val paths = listOf("相册 (DCIM)", "下载 (Downloads)", "自定义")
                    paths.forEach { path ->
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            RadioButton(
                                selected = viewModel.downloadPath == path,
                                onClick = { viewModel.saveDownloadPath(path) }
                            )
                            Text(path, style = MaterialTheme.typography.bodySmall)
                        }
                    }
                    if (viewModel.downloadPath == "自定义") {
                        OutlinedButton(
                            onClick = { dirPicker.launch(null) },
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Icon(Icons.Filled.FolderOpen, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(Modifier.width(8.dp))
                            Text(viewModel.customDirUri?.let { "已选择文件夹" } ?: "选择保存文件夹",
                                style = MaterialTheme.typography.bodySmall)
                        }
                    }
                    Spacer(Modifier.height(8.dp))
                }
            }
        }

        Spacer(Modifier.weight(1f))
        Text("视频保存在服务器下载后传输到手机", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Spacer(Modifier.height(16.dp))
    }
}
