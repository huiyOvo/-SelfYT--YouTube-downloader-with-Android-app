# ProGuard rules for YTDownloader
-keepattributes Signature
-keepattributes *Annotation*
-keep class com.ytdownloader.data.model.** { *; }
