@echo off
set ANDROID_SDK_ROOT=C:\Users\ASUS\AppData\Local\Android\Sdk

echo Accepting all SDK licenses...
(
echo y
echo y
echo y
echo y
echo y
echo y
echo y
echo y
echo y
echo y
echo y
echo y
echo y
echo y
echo y
echo y
echo y
echo y
echo y
echo y
echo y
echo y
echo y
echo y
) | C:\Users\ASUS\AppData\Local\Android\Sdk\cmdline-tools\latest\bin\sdkmanager.bat --proxy=http --proxy_host=127.0.0.1 --proxy_port=7892 --licenses --sdk_root=%ANDROID_SDK_ROOT%

echo.
echo Installing SDK packages...
echo y | C:\Users\ASUS\AppData\Local\Android\Sdk\cmdline-tools\latest\bin\sdkmanager.bat --proxy=http --proxy_host=127.0.0.1 --proxy_port=7892 platforms;android-34 build-tools;34.0.0 platform-tools --sdk_root=%ANDROID_SDK_ROOT%

echo.
echo Done!
