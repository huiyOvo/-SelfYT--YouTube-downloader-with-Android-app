@echo off
chcp 65001 >nul
title YT下载器 后端服务

cd /d "%~dp0"

echo.
echo ============================================
echo      YT下载器 后端服务 v1.0
echo ============================================
echo.

:: 检查 Python
python --version >nul 2>&1
if %errorlevel% neq 0 (
    echo [错误] 未找到 Python，请先安装 Python 3.11+
    pause
    exit /b 1
)

:: 检查并安装依赖
echo [1/3] 检查依赖...
pip show flask flask-cors yt-dlp >nul 2>&1
if %errorlevel% neq 0 (
    echo 正在安装依赖...
    pip install -r requirements.txt -q
    if %errorlevel% neq 0 (
        echo [错误] 依赖安装失败
        pause
        exit /b 1
    )
    echo 依赖安装完成
) else (
    echo 依赖已就绪
)

:: 检查 ffmpeg
echo [2/3] 检查 ffmpeg...
ffmpeg -version >nul 2>&1
if %errorlevel% neq 0 (
    echo [警告] 未找到 ffmpeg，视频合并/压缩功能不可用
) else (
    echo ffmpeg 已就绪
)

:: 获取本机 IP
echo [3/3] 获取网络信息...
for /f "tokens=2 delims=:" %%a in ('ipconfig ^| findstr /c:"IPv4"') do (
    set LOCAL_IP=%%a
    set LOCAL_IP=!LOCAL_IP:~1!
    goto :found_ip
)
:found_ip

echo.
echo ============================================
echo     服务启动中...
echo     本机地址: http://!LOCAL_IP!:5000
echo     代理地址: 见 config.json
echo     按 Ctrl+C 停止服务
echo ============================================
echo.

python app.py

pause
