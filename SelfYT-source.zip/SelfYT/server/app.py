import os
import json
import re
import shutil
import subprocess
import uuid
import threading
from pathlib import Path

from flask import Flask, request, jsonify, send_file
from flask_cors import CORS
import yt_dlp

app = Flask(__name__)
CORS(app)

BASE_DIR = Path(__file__).parent
DOWNLOAD_DIR = BASE_DIR / "downloads"
DOWNLOAD_DIR.mkdir(exist_ok=True)
CONFIG_FILE = BASE_DIR / "config.json"

progress_store = {}
download_results = {}
cancel_flags = {}


def load_config():
    if CONFIG_FILE.exists():
        with open(CONFIG_FILE, "r", encoding="utf-8") as f:
            return json.load(f)
    return {}


def save_config(config):
    with open(CONFIG_FILE, "w", encoding="utf-8") as f:
        json.dump(config, f, ensure_ascii=False, indent=2)


def get_ydl_opts(proxy=None, extra_opts=None):
    """Build yt-dlp options, optionally with proxy."""
    opts = {
        "quiet": True,
        "no_warnings": True,
    }
    if proxy:
        opts["proxy"] = proxy
    else:
        config = load_config()
        if config.get("proxy"):
            opts["proxy"] = config["proxy"]
    if extra_opts:
        opts.update(extra_opts)
    return opts


def create_progress_hook(task_id):
    def hook(d):
        if cancel_flags.get(task_id):
            raise Exception("CANCELLED")
        if d["status"] == "downloading":
            total = d.get("total_bytes") or d.get("total_bytes_estimate", 0)
            downloaded = d.get("downloaded_bytes", 0)
            progress_store[task_id] = {
                "status": "downloading",
                "percent": round(downloaded / total * 100, 1) if total else 0,
                "speed": d.get("speed", 0),
                "eta": d.get("eta", 0),
                "downloaded_bytes": downloaded,
                "total_bytes": total,
            }
        elif d["status"] == "finished":
            progress_store[task_id] = {
                "status": "processing",
                "message": "合并/转换中...",
            }

    return hook


def find_output_file(directory, task_id):
    """Find the output file in the task directory."""
    for f in directory.iterdir():
        if f.is_file():
            return f
    return None


@app.route("/api/health")
def health():
    config = load_config()
    return jsonify({
        "status": "ok",
        "message": "服务运行中",
        "proxy_configured": bool(config.get("proxy")),
    })


@app.route("/api/config", methods=["GET", "POST"])
def config_handler():
    if request.method == "GET":
        return jsonify(load_config())
    else:
        data = request.get_json()
        config = load_config()
        if "proxy" in data:
            config["proxy"] = data["proxy"]
        save_config(config)
        return jsonify({"status": "ok", "message": "配置已保存"})


@app.route("/api/info", methods=["POST"])
def get_video_info():
    data = request.get_json()
    url = data.get("url", "").strip()
    proxy = data.get("proxy", "").strip() or None

    if not url:
        return jsonify({"error": "请提供 YouTube URL"}), 400

    try:
        with yt_dlp.YoutubeDL(get_ydl_opts(proxy=proxy)) as ydl:
            info = ydl.extract_info(url, download=False)
    except Exception as e:
        return jsonify({"error": f"解析失败: {str(e)}"}), 400

    duration = info.get("duration", 0) or 0
    formats = info.get("formats", [])

    # Separate video-only and audio-only formats
    video_formats = []
    audio_formats = []
    combined_formats = []
    for f in formats:
        has_video = f.get("vcodec") != "none"
        has_audio = f.get("acodec") != "none"
        if has_video and has_audio:
            combined_formats.append(f)
        elif has_video and not has_audio:
            video_formats.append(f)
        elif has_audio and not has_video:
            audio_formats.append(f)

    # Best audio (prefer m4a, then highest bitrate)
    best_audio = max(
        audio_formats,
        key=lambda f: (
            1 if f.get("ext") == "m4a" else 0,
            f.get("abr", 0) or 0,
        ),
    ) if audio_formats else None

    # Build per-resolution best video picker
    resolution_map = {}
    for f in video_formats + combined_formats:
        height = f.get("height")
        if not height or height < 144:
            continue
        current_tbr = f.get("tbr", 0) or 0
        if height not in resolution_map:
            resolution_map[height] = f
        else:
            existing = resolution_map[height]
            existing_tbr = existing.get("tbr", 0) or 0
            # Prefer MP4, then higher bitrate
            if f.get("ext") == "mp4" and existing.get("ext") != "mp4":
                resolution_map[height] = f
            elif f.get("ext") == existing.get("ext") and current_tbr > existing_tbr:
                resolution_map[height] = f

    # Estimate MP3 size (at ~192kbps)
    audio_size = int(192 * 1000 / 8 * duration) if duration else None

    # Build video options with better size estimation
    video_options = []
    for height in sorted(resolution_map.keys(), reverse=True):
        vf = resolution_map[height]
        vbr = vf.get("vbr", 0) or 0
        abr = best_audio.get("abr", 0) or 0 if best_audio else 0

        # Try multiple methods for size estimation
        v_size = vf.get("filesize") or vf.get("filesize_approx")
        a_size = best_audio.get("filesize") or best_audio.get("filesize_approx") if best_audio else None

        if vf.get("vcodec") != "none" and vf.get("acodec") != "none":
            # Already combined: use its own size
            est_size = vf.get("filesize") or vf.get("filesize_approx")
        elif v_size and a_size:
            est_size = v_size + a_size
        elif vbr and duration:
            audio_bitrate = abr if not a_size else 0
            est_size = int((vbr + audio_bitrate) * 1000 / 8 * duration)
        else:
            # Fallback: estimate from total bitrate
            tbr = vf.get("tbr", 0) or 0
            if tbr and duration:
                est_size = int(tbr * 1000 / 8 * duration)
            else:
                est_size = None

        video_options.append(
            {
                "resolution": f"{height}p",
                "height": height,
                "ext": "mp4",
                "filesize": est_size,
                "filesize_str": format_size(est_size) if est_size else "未知",
                "note": vf.get("format_note", ""),
                "fps": vf.get("fps"),
            }
        )

    # Deduplicate: keep only one entry per unique resolution
    seen = set()
    unique_video = []
    for vo in video_options:
        if vo["height"] not in seen:
            seen.add(vo["height"])
            unique_video.append(vo)
    video_options = unique_video

    return jsonify(
        {
            "id": info.get("id"),
            "title": info.get("title"),
            "thumbnail": info.get("thumbnail"),
            "duration": duration,
            "duration_str": format_duration(duration),
            "uploader": info.get("uploader"),
            "webpage_url": info.get("webpage_url"),
            "video_options": video_options,
            "audio_option": {
                "ext": "mp3",
                "filesize": audio_size,
                "filesize_str": format_size(audio_size) if audio_size else "未知",
                "bitrate": "192kbps",
            },
        }
    )


@app.route("/api/download", methods=["POST"])
def start_download():
    data = request.get_json()
    url = data.get("url", "").strip()
    resolution = data.get("resolution", "720p")
    fmt = data.get("format", "mp4")
    compress = data.get("compress", False)

    if not url:
        return jsonify({"error": "请提供 YouTube URL"}), 400

    task_id = str(uuid.uuid4())[:8]
    task_dir = DOWNLOAD_DIR / task_id
    task_dir.mkdir(exist_ok=True)

    if fmt == "mp3":
        format_str = "bestaudio/best"
        output_template = str(task_dir / "%(title)s.%(ext)s")
        postprocessors = [
            {
                "key": "FFmpegExtractAudio",
                "preferredcodec": "mp3",
                "preferredquality": "192",
            }
        ]
        compress = False  # no compress for audio
    else:
        height = resolution.replace("p", "")
        format_str = (
            f"bestvideo[height<={height}]+bestaudio/best[height<={height}]"
        )
        output_template = str(task_dir / "%(title)s.%(ext)s")
        postprocessors = [
            {"key": "FFmpegVideoConvertor", "preferedformat": "mp4"}
        ]

    ydl_opts = get_ydl_opts(
        proxy=data.get("proxy", "").strip() or None,
        extra_opts={
            "format": format_str,
            "outtmpl": output_template,
            "progress_hooks": [create_progress_hook(task_id)],
            "postprocessors": postprocessors,
            "merge_output_format": "mp4",
        },
    )

    progress_store[task_id] = {"status": "starting", "message": "准备下载..."}
    cancel_flags[task_id] = False

    def do_download():
        try:
            with yt_dlp.YoutubeDL(ydl_opts) as ydl:
                info = ydl.extract_info(url, download=False)
                duration = info.get("duration", 0) or 0
                ydl.download([url])

            if cancel_flags.get(task_id):
                shutil.rmtree(task_dir, ignore_errors=True)
                progress_store[task_id] = {"status": "cancelled", "message": "已取消"}
                return

            output_file = find_output_file(task_dir, task_id)
            if not output_file:
                progress_store[task_id] = {"status": "error", "message": "下载完成但找不到文件"}
                return

            # Compress if requested
            if compress and output_file.suffix in (".mp4", ".mkv", ".webm"):
                progress_store[task_id] = {"status": "compressing", "message": "NVENC压缩中...", "percent": 0}
                success = compress_video(task_id, output_file, duration)
                if cancel_flags.get(task_id):
                    return
                if not success:
                    progress_store[task_id] = {"status": "error", "message": "压缩失败"}
                    return
                output_file = find_output_file(task_dir, task_id) or output_file

            download_results[task_id] = {
                "status": "complete",
                "filename": output_file.name,
                "filesize": output_file.stat().st_size,
                "filesize_str": format_size(output_file.stat().st_size),
                "task_id": task_id,
            }
            progress_store[task_id] = {"status": "complete", "filename": output_file.name}
        except Exception as e:
            msg = str(e)
            if cancel_flags.get(task_id) or "CANCELLED" in msg:
                shutil.rmtree(task_dir, ignore_errors=True)
                progress_store[task_id] = {"status": "cancelled", "message": "已取消"}
            else:
                progress_store[task_id] = {"status": "error", "message": msg}

    thread = threading.Thread(target=do_download, daemon=True)
    thread.start()

    return jsonify({"task_id": task_id})


@app.route("/api/progress/<task_id>")
def get_progress(task_id):
    data = progress_store.get(task_id)
    if not data:
        return jsonify({"status": "not_found", "message": "任务不存在"})

    if data.get("status") == "complete":
        result = download_results.get(task_id, {})
        return jsonify(
            {
                "status": "complete",
                "filename": result.get("filename"),
                "filesize_str": result.get("filesize_str"),
            }
        )

    return jsonify(data)


@app.route("/api/file/<task_id>")
def download_file(task_id):
    result = download_results.get(task_id)
    if not result:
        return jsonify({"error": "文件不存在或未完成"}), 404

    filepath = DOWNLOAD_DIR / task_id / result["filename"]
    if not filepath.exists():
        return jsonify({"error": "文件已被清理"}), 404

    return send_file(
        filepath,
        as_attachment=True,
        download_name=result["filename"],
        mimetype="application/octet-stream",
    )


@app.route("/api/cancel/<task_id>", methods=["POST"])
def cancel_download(task_id):
    cancel_flags[task_id] = True
    return jsonify({"status": "ok", "message": "已发送取消信号"})


@app.route("/api/file/<task_id>", methods=["DELETE"])
def delete_file(task_id):
    task_dir = DOWNLOAD_DIR / task_id
    shutil.rmtree(task_dir, ignore_errors=True)
    download_results.pop(task_id, None)
    progress_store.pop(task_id, None)
    cancel_flags.pop(task_id, None)
    return jsonify({"status": "ok", "message": "已删除"})


@app.route("/api/tasks")
def list_tasks():
    tasks = []
    # Active downloads
    for tid, prog in progress_store.items():
        tasks.append({
            "task_id": tid,
            "status": prog.get("status", "unknown"),
            "percent": prog.get("percent", 0),
            "speed": prog.get("speed", 0),
            "message": prog.get("message", ""),
        })
    # Completed files (not in progress_store anymore but still on disk)
    for tid, result in download_results.items():
        if tid not in progress_store:
            tasks.append({
                "task_id": tid,
                "status": "complete",
                "filename": result.get("filename"),
                "filesize_str": result.get("filesize_str"),
            })
    return jsonify({"tasks": tasks})


def compress_video(task_id, input_file, duration):
    """Compress video using NVENC to 720p, target ~95MB."""
    output_file = input_file.with_suffix(".compressed.mp4")

    if duration and duration > 0:
        video_bitrate = int((778240 - 128 * duration) / duration)
        video_bitrate = max(500, min(8000, video_bitrate))
    else:
        video_bitrate = 2000

    cmd = [
        "ffmpeg", "-y",
        "-i", str(input_file),
        "-vf", "scale='min(1280,iw)':-2",
        "-c:v", "h264_nvenc",
        "-preset", "p1",
        "-rc", "vbr",
        "-b:v", f"{video_bitrate}k",
        "-maxrate", f"{int(video_bitrate * 1.5)}k",
        "-bufsize", f"{int(video_bitrate * 2)}k",
        "-c:a", "aac",
        "-b:a", "128k",
        "-movflags", "+faststart",
        str(output_file),
    ]

    try:
        process = subprocess.Popen(
            cmd,
            stderr=subprocess.PIPE,
            stdout=subprocess.DEVNULL,
            text=True,
            encoding="utf-8",
            errors="replace",
        )

        for line in process.stderr:
            if cancel_flags.get(task_id):
                process.terminate()
                return False

            match = re.search(r"time=(\d+):(\d+):(\d+)\.(\d+)", line)
            if match and duration:
                h, m, s, cs = map(int, match.groups())
                elapsed = h * 3600 + m * 60 + s + cs / 100
                pct = min(round(elapsed / duration * 100, 1), 99.9)
                progress_store[task_id] = {
                    "status": "compressing",
                    "message": "NVENC压缩中...",
                    "percent": pct,
                }

        process.wait()

        if process.returncode != 0:
            return False

        input_file.unlink()
        output_file.rename(input_file)
        return True

    except Exception:
        return False


def format_size(size_bytes):
    if size_bytes is None:
        return "未知"
    for unit in ["B", "KB", "MB", "GB"]:
        if size_bytes < 1024:
            return f"{size_bytes:.1f} {unit}"
        size_bytes /= 1024
    return f"{size_bytes:.1f} TB"


def format_duration(seconds):
    if not seconds:
        return "未知"
    m, s = divmod(seconds, 60)
    h, m = divmod(m, 60)
    if h:
        return f"{h}:{m:02d}:{s:02d}"
    return f"{m}:{s:02d}"


if __name__ == "__main__":
    # 0.0.0.0 allows LAN access from your phone
    app.run(host="0.0.0.0", port=5000, debug=True)
