import subprocess
import sys

SDK_ROOT = r"C:\Users\ASUS\AppData\Local\Android\Sdk"
SDKMANAGER = r"C:\Users\ASUS\AppData\Local\Android\Sdk\cmdline-tools\latest\bin\sdkmanager.bat"

def run_sdkmanager(*args):
    cmd = [
        SDKMANAGER,
        "--proxy=http", "--proxy_host=127.0.0.1", "--proxy_port=7892",
        "--sdk_root=" + SDK_ROOT,
    ] + list(args)

    proc = subprocess.Popen(cmd, stdin=subprocess.PIPE,
                            stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                            text=True)
    out, _ = proc.communicate(input="y\n" * 30)
    print(out)
    return proc.returncode

print("=== Accepting licenses ===")
ret = run_sdkmanager("--licenses")
print(f"Exit code: {ret}")

print("\n=== Installing SDK packages ===")
ret = run_sdkmanager("platforms;android-34", "build-tools;34.0.0", "platform-tools")
print(f"Exit code: {ret}")
print("\nDone!")
